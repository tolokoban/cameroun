// Container for Google's font Mytery Quest.
