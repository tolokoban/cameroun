require("font.mystery-quest");

exports.onPage = function() {};
